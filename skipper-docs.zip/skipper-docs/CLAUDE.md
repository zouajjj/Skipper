# Skipper — Claude Code Project Context

Skipper is a MARTA-powered transit + eatery PWA for Atlanta. Users share their location, see nearby
MARTA rail and bus stops seeded from PostGIS, pick a restaurant or McDonald's, and get a routed
trip plan with real-time arrival enrichment from a modular transit provider adapter.

This file is the authoritative context document for Claude Code. Read it fully before touching any
file in this repo. Every architectural decision here was made deliberately — check docs/ before
proposing alternatives.

---

## Repo Layout

```
skipper/
├── CLAUDE.md                          ← you are here
├── docs/
│   ├── architecture.md                ← system design, data flow, decision log
│   ├── database.md                    ← PostGIS schema, queries, index strategy
│   ├── seeding.md                     ← seed pipeline phases, city scaling estimates
│   ├── transit-adapter.md             ← TransitProvider interface, all adapters
│   └── frontend.md                    ← PWA structure, Haversine, canvas map, UI
├── src/
│   ├── transit/
│   │   ├── TransitProvider.ts         ← interface (DO NOT change — all adapters depend on it)
│   │   ├── ProviderRegistry.ts        ← getProvider(agencyId) — add cities here
│   │   ├── ArrivalCache.ts            ← 30s TTL in-memory cache
│   │   └── adapters/
│   │       ├── MartaAdapter.ts        ← keyless, Atlanta rail + bus
│   │       ├── WmataAdapter.ts        ← DC Metro (requires WMATA_API_KEY)
│   │       ├── CtaAdapter.ts          ← Chicago (requires CTA_API_KEY)
│   │       ├── MtaAdapter.ts          ← NYC (requires MTA_API_KEY)
│   │       ├── TflAdapter.ts          ← London (keyless at low rate)
│   │       └── GtfsRtAdapter.ts       ← generic binary GTFS-RT for any agency
│   ├── api/
│   │   ├── nearby-stops.ts            ← GET /api/nearby-stops
│   │   ├── route-plan.ts              ← POST /api/route-plan
│   │   └── arrivals.ts                ← GET /api/arrivals (proxies transit adapter)
│   ├── db/
│   │   └── index.ts                   ← pg Pool, query helper
│   └── utils/
│       └── haversine.ts               ← client-side fallback distance calc
├── scripts/
│   ├── seed_rail.py                   ← Phase 1: 38 rail stations via COPY
│   ├── seed_bus.py                    ← Phase 2: ~7k bus stops, drops/rebuilds GIST
│   ├── seed_pois.py                   ← Phase 3: Overpass API → pois table
│   └── run_seed.py                    ← orchestrator (--phases rail bus poi)
├── public/
│   └── skipper.html                   ← standalone PWA (works without backend)
└── .env.example
```

---

## Tech Stack

| Layer | Choice | Reason |
|---|---|---|
| DB | PostgreSQL 16 + PostGIS 3.4 | Spatial indexing, GIST KNN, GEOGRAPHY type |
| Backend | Node.js 18+ / Express | fetch() built-in, pg driver |
| Frontend | Vanilla HTML/CSS/JS | PWA, works offline, no build step |
| Distance math | Haversine (client) / ST_Distance (server) | Offline fallback, no Mapbox quota |
| POI data | Overpass/OpenStreetMap | Free, no key, good Atlanta coverage |
| Transit real-time | TransitProvider adapter | Modular — swap agency without touching routing |
| Maps deep-link | Google Maps / Apple Maps URI | No SDK, no token, system native |

---

## Mock Coordinates

Development and testing always use:
```
lat: 33.74976256840587
lon: -84.37726057107493
```
This is near King Memorial Station (BLUE/GREEN lines), 0.28 mi away. Every seed script,
test fixture, and demo uses these coordinates. Do not change them without updating all fixtures.

---

## Current Sprint Status

### Done
- [x] Static routing engine — Haversine, nearest stop, leg assembly
- [x] PostGIS schema — `marta_stops`, `pois`, `marta_lines`, `route_cache`
- [x] Three-phase seed pipeline — rail / bus / POIs with load balancing
- [x] TransitProvider interface + all five adapters (MARTA, WMATA, CTA, MTA, TfL)
- [x] MARTA adapter — keyless rail + bus real-time endpoints
- [x] Arrival enrichment with graceful fallback to cached `stop_times`
- [x] Standalone PWA (`skipper.html`) — location, Overpass eateries, canvas MARTA map
- [x] Bus stop flow UI — seeded stops → McDonald's POI routing
- [x] Transit adapter switcher UI — live provider swap, arrival simulation

### Next Sprint
- [ ] Wire `/api/nearby-stops` and `/api/route-plan` to real PostGIS DB
- [ ] Replace Overpass per-request fetch with nightly `sync_pois.py` cron + indexed table
- [ ] Add GTFS `stop_times` table for schedule fallback
- [ ] Live vehicle positions on canvas map (MARTA bus API)
- [ ] "Did the bus arrive?" confirmation flow (stretch)

---

## Hard Rules — Read Before Changing Anything

1. **`TransitProvider` interface is frozen.** All five adapters implement it. Any change to
   `getArrivals()`, `getVehicles()`, or `ping()` signatures breaks all adapters simultaneously.
   If you need to extend it, add an optional method only.

2. **Routing never calls a transit API directly.** The only place that touches `TransitProvider`
   is `src/api/arrivals.ts` → `enrichWithArrivals()`. The route plan is always built from PostGIS.

3. **PostGIS parameter order: `ST_MakePoint(lon, lat)` — longitude first.** This is the single
   most common mistake. `ST_MakePoint(lat, lon)` puts Atlanta in the ocean. Every query in this
   codebase uses `$2, $1` binding where `$1=lat, $2=lon` to enforce this.

4. **Always use `GEOGRAPHY` type, not `GEOMETRY`.** GEOGRAPHY returns distances in meters using
   the geodetic model. No projection needed for Atlanta's scope.

5. **Use `<->` KNN operator for ORDER BY nearest, not `ST_Distance(...)`.** KNN uses the GIST
   index. `ST_Distance` in ORDER BY does a full table scan.

6. **Seed phases must run in order: rail → bus → POIs.** Bus seed drops/rebuilds the GIST index.
   If POIs seed runs during the index drop window, spatial queries will fail.

7. **All transit API calls are proxied through `/api/arrivals`.** Never expose API keys in the
   PWA frontend. The backend is the only place that holds keys.

8. **`ON CONFLICT DO UPDATE` everywhere.** Every seed INSERT is idempotent. Re-running any seed
   phase must be safe.

---

## Environment Variables

```bash
# .env.example
DATABASE_URL=postgresql://localhost/skipper

# Transit adapters — only fill the ones you have
WMATA_API_KEY=          # DC Metro — register at developer.wmata.com
CTA_API_KEY=            # Chicago CTA — register at transitchicago.com/developers
MTA_API_KEY=            # NYC MTA — register at bustime.mta.info
TFL_APP_ID=             # London TfL — optional, increases rate limit
TFL_APP_KEY=            # London TfL — pair with TFL_APP_ID

# MARTA requires no key
```

---

## Key Commands

```bash
# Database setup
psql skipper < scripts/schema.sql

# Seed (Atlanta, all phases)
python scripts/run_seed.py --db postgresql://localhost/skipper

# Seed rail only (fast, safe to re-run)
python scripts/run_seed.py --phases rail

# Dev server
npm run dev

# Open standalone PWA (no backend needed)
open public/skipper.html
```

---

## Related Docs

- `docs/architecture.md` — full data flow diagram, decision log
- `docs/database.md` — complete PostGIS schema + all named queries
- `docs/seeding.md` — seed pipeline, city scaling formula, load estimates
- `docs/transit-adapter.md` — TransitProvider interface, adding new cities
- `docs/frontend.md` — PWA structure, canvas map, "Open in Maps" deep-link
